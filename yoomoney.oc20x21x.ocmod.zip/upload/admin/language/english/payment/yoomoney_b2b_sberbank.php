<?php
$_['heading_title'] = 'YooKassa: Sberbank Business Online';
$_['text_yoomoney'] = '<a onclick="window.open(\'https://yookassa.ru/en/\');"><img src="view/image/payment/yoomoney.png" alt="Sberbank Business Online" title="Sberbank Business Online" /></a>';