<?php

require_once dirname(__FILE__).DIRECTORY_SEPARATOR.'yoomoney.php';

class ControllerPaymentYoomoneyB2bSberbank extends ControllerExtensionPaymentYoomoney
{

}

class ControllerExtensionPaymentYoomoneyB2bSberbank extends ControllerPaymentYoomoneyB2bSberbank
{

}