<?php

namespace YaMoney\Request\Refunds;

/**
 * Класс объекта ответа от API при запросе одного конкретного возврата
 *
 * @package YaMoney\Request\Refunds
 */
class RefundResponse extends AbstractRefundResponse
{}
