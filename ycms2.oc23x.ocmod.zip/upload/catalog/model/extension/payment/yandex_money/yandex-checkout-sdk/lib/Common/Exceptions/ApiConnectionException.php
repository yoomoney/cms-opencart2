<?php


namespace YaMoney\Common\Exceptions;


class ApiConnectionException extends ApiException
{

}