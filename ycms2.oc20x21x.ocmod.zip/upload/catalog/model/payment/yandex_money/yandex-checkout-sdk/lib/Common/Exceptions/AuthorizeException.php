<?php

namespace YaMoney\Common\Exceptions;


class AuthorizeException extends ApiException
{

}